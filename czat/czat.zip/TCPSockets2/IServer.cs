﻿/*
 * Telemedycyna i Technologie Sieciowe
 * Laboratorium. Gniazda sieciowe cz.2: Wielowatkowa obsluga polaczen
 * Interfejs dla klas serwera
 * v.0.1.a, 2018-03-12, Marcin.Rudzki@polsl.pl 
 */

using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;

namespace TCPSockets2
{
    public interface IServer
    {
        void Start();
        void Stop();
        void Closing();
    }
}
